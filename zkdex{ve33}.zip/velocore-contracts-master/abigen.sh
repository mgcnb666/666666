forge inspect src/interfaces/IVault.sol:IVault abi > abi/Vault.json
forge inspect src/lens/VelocoreLens.sol:VelocoreLens abi > abi/Lens.json
forge inspect src/pools/constant-product/ConstantProductPool.sol:ConstantProductPool abi > abi/CPP.json